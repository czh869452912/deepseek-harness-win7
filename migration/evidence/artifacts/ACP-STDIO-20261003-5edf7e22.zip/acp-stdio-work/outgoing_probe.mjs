import {Connection} from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/jsonrpc.js';
import {ndJsonStream} from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/stream.js';
import {writeFileSync} from 'node:fs';

const observations = [];
const settled = async () => {for (let iteration = 0; iteration < 30; iteration++) await new Promise(resolve => setImmediate(resolve));};
for (const mode of ['result', 'remote-error', 'invalid', 'unknown', 'preabort', 'cancel', 'close', 'write-failure', 'mapper']) {
  const output = [];
  let input;
  const readable = new ReadableStream({start(controller) {input = controller;}});
  const writable = new WritableStream({write(bytes) {
    output.push(JSON.parse(new TextDecoder().decode(bytes)));
    if (mode === 'write-failure') throw new Error('write fixture failure');
  }});
  const connection = new Connection(ndJsonStream(writable, readable), []);
  const push = value => input.enqueue(new TextEncoder().encode(JSON.stringify(value) + '\n'));
  const controller = new AbortController();
  if (mode === 'preabort') controller.abort('fixture cancellation');
  let outcome;
  const pending = connection.sendRequest('fixture/request', {value: '中文'},
    mode === 'mapper' ? () => {throw new Error('mapper fixture failure');} : value => ({mapped: value}),
    {cancellationSignal: controller.signal}).then(value => {outcome = {value};}, error => {
      outcome = {error: {message: error.message, ...(error.code === undefined ? {} : {code: error.code}),
        ...(error.data === undefined ? {} : {data: error.data})}};
    });
  await settled();
  if (mode === 'cancel') {controller.abort('fixture cancellation'); await settled();}
  if (mode === 'unknown') {push({jsonrpc: '2.0', id: '0', result: 'ignored'}); await settled();}
  const settledBeforeReply = outcome !== undefined;
  if (mode === 'close') input.close();
  else if (mode !== 'write-failure') push(mode === 'remote-error'
    ? {jsonrpc: '2.0', id: 0, error: {code: -32602, message: 'fixture rejected', data: {value: false}}}
    : mode === 'invalid' ? {jsonrpc: '2.0', id: 0, result: 'ambiguous', error: {code: -32603, message: 'invalid'}}
    : {jsonrpc: '2.0', id: 0, result: 'accepted'});
  await pending;
  await settled();
  observations.push({mode, output, settledBeforeReply, outcome, closed: connection.signal.aborted});
  connection.close();
}
writeFileSync(process.argv[2], JSON.stringify(observations, null, 2));
