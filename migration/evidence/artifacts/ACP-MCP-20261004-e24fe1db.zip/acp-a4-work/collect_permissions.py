import hashlib
from datetime import datetime
import json
import platform
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
import migration
import verify_release

STAMP = datetime.now().strftime('%Y%m%d')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    output = ROOT / '.goose/out/acp-permissions-clean-gate'
    summary = json.loads((output / 'summary.json').read_text(encoding='utf-8'))
    assert summary['result'] == 'passed' and summary['publishable'] is True
    assert summary['worktree_dirty'] is False
    candidate = summary['product_commit']
    assert verify_release.git('rev-parse', 'HEAD') == candidate
    assert not verify_release.git('status', '--porcelain')
    frozen = json.loads((output / 'inputs.json').read_text(encoding='utf-8'))
    assert frozen == verify_release.source_snapshot()
    assert digest(output / 'inputs.json') == summary['input_manifest_sha256']
    assert digest(Path(summary['archive'])) == summary['archive_sha256']
    for name, expected in summary['receipts'].items():
        assert digest(output / (name + '.json')) == expected, name
    counts = ET.parse(str(output / 'pytest.xml')).getroot().find('testsuite').attrib
    assert counts['failures'] == '0' and counts['errors'] == '0'
    source_counts = {}
    for config, expected in zip(verify_release.OFFICIAL_CONFIGS, [80, 100, 197, 100, 139, 3]):
        log = (output / ('official-' + config + '.log')).read_text(encoding='utf-8')
        matches = re.findall(r'Tests\s+(\d+) passed', re.sub(r'\x1b\[[0-9;]*m', '', log))
        assert matches == [str(expected)], (config, matches)
        source_counts[config] = expected
    bundle = ROOT / ('migration/evidence/artifacts/ACP-PERMISSIONS-' + STAMP + '-' + candidate[:8] + '.zip')
    with zipfile.ZipFile(str(bundle), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for label in ('acp-permissions-clean-gate', 'acp-a4-work'):
            directory = ROOT / '.goose/out' / label
            for path in sorted(directory.rglob('*')):
                if any(part in ('vite-cache', 'mcp-vite-cache', '__pycache__') for part in path.relative_to(directory).parts):
                    continue
                if path.is_file():
                    archive.write(str(path), label + '/' + path.relative_to(directory).as_posix())
    with zipfile.ZipFile(str(bundle)) as archive:
        assert archive.testzip() is None
        for name, expected in summary['receipts'].items():
            assert hashlib.sha256(archive.read('acp-permissions-clean-gate/' + name + '.json')).hexdigest() == expected
    product_inputs = {name: value for name, value in frozen.items() if not name.startswith(('migration/', 'docs/'))}
    backend_inputs = {name: value for name, value in product_inputs.items() if not name.startswith('packages/')}
    frontend = json.loads((ROOT / 'scripts/frontend-inputs.json').read_text(encoding='utf-8'))
    for item in frontend['files']:
        assert frozen[item['path']] == item['sha256']
        backend_inputs[item['path']] = item['sha256']
    tasks = ['MIG-CURRENT-RELEASE-GATE-003', 'MIG-ACP-PROMPT-OWNERSHIP-001',
             'MIG-CORDIS-001', 'MIG-AGENT-LIFECYCLE-002', 'MIG-AGENT-CONFIG-003',
             'MIG-SESSION-COLD-003', 'MIG-SESSION-LIVE-004', 'MIG-SESSION-PREPARED-005',
             'MIG-SESSION-STORAGE-006', 'MIG-SESSION-PROJECTION-007', 'MIG-SPINE-001',
             'MIG-PORTABLE-001', 'MIG-ACP-SESSION-CONTROLS-003', 'MIG-ACP-CONFIG-OUTPUT-004', 'MIG-ACP-STDIO-005', 'MIG-ACP-PERMISSIONS-006']
    created, changes = [], []
    artifact = {'path': bundle.relative_to(ROOT).as_posix(), 'sha256': digest(bundle)}
    passed = int(counts['tests']) - int(counts['skipped'])
    for task_id in tasks:
        task_path = ROOT / 'migration/tasks' / (task_id + '.json')
        task = json.loads(task_path.read_text(encoding='utf-8'))
        evidence_id = 'RUN-ACP-PERMISSIONS-' + STAMP + '-' + task_id[len('MIG-'):]
        selected_inputs = product_inputs if task_id == tasks[0] else backend_inputs
        record = {'id': evidence_id, 'target_upstream': summary['target_upstream'],
            'product_commit': candidate, 'kind': 'acceptance', 'task_id': task_id,
            'acceptance_digest': migration.acceptance_digest(task), 'result': 'passed', 'validity': 'current',
            'exit_code': 0, 'commands': ['.venv/Scripts/python.exe scripts/verify_release.py --browser "'
                + summary['browser'] + '" --output-dir .goose/out/acp-permissions-clean-gate'],
            'environment': {'python': summary['python'], 'os': platform.platform(), 'cwd': str(ROOT),
                            'node': summary['node'], 'browser': summary['browser']},
            'contract_revisions': {item['contract']: item['revision'] for item in task['provides'] + task['requires']},
            'inputs': [{'path': name, 'sha256': selected_inputs[name]} for name in sorted(selected_inputs)],
            'artifacts': [artifact], 'scope': ('Clean current-Windows candidate, Python 3.8.10; %d passed, %s platform skips; '
                '20 required browser/Portable/ACP/permission process lanes, %d unchanged original tests, %d selected paired drivers, '
                'exact C58, eight prior bug predicates and two reviewed malformed ACP grant responses; actual extracted ZIP including six permission processes. Only this task bounded contract is accepted. '
                'No complete ACP/MCP/subagent, full upstream, OAuth/JS, paid model, '
                'remote Actions, fresh uncached bootstrap or deferred Win7 certification. '
                'Earlier A4 permission observer/process failures and negative/prototype MCP provider probes are archived without MCP acceptance, '
                'not passing evidence.') % (passed, counts['skipped'], sum(source_counts.values()), len(verify_release.PAIRED_DRIVERS)),
            'archive_sha256': summary['archive_sha256'], 'gate_summary_sha256': digest(output / 'summary.json'),
            'frozen_input_manifest_sha256': summary['input_manifest_sha256']}
        write_json(ROOT / 'migration/evidence' / (evidence_id + '.json'), record)
        created.append(evidence_id)
        task.update(state='integrated', candidate_commit=candidate, integrated_commit=candidate, open_findings=[])
        task['evidence_ids'].append(evidence_id)
        if task_id == tasks[0]:
            task['next_action'] = '当前 Windows clean candidate %s 完整门禁通过，绑定实际 ZIP；28 配对/619 原版源测试及二十条必需 lane，不认证全范围、远程 Actions、无缓存安装或 Win7。' % candidate[:8]
        elif task_id == tasks[1]:
            task['next_action'] = '精确 prompt ownership 在持久 controls 候选重验；模型配置/有序语义输出已按子合同验收；一次性权限独立合同同时验收；继续 MCP/subagent 的必要消费者闭包。'
        elif task_id == 'MIG-ACP-SESSION-CONTROLS-003':
            task['next_action'] = 'new/list/resume/close 持久生命周期的有界合同在 clean candidate %s 验收；A2 模型配置/语义输出独立合同同时验收；一次性权限独立合同验收；继续 A4 MCP/subagent。父范围与 Win7 不自动完成。' % candidate[:8]
        elif task_id == 'MIG-ACP-CONFIG-OUTPUT-004':
            task['next_action'] = '模型配置、admission/turn pin 和 ordered committed output 有界合同在 clean candidate %s 验收；一次性权限独立合同验收；继续 A4 MCP/subagent，完整 ACP 未认证。' % candidate[:8]
        if task_id == 'MIG-ACP-STDIO-005':
            task['next_action'] = 'canonical stdio、九方法 SDK 参数/协议、真实并发取消 EOF 与解压包 stdio 在 clean candidate %s 有界验收；一次性权限独立合同验收；继续 A4 MCP/subagent 和 B/C/D，不认证全部 ACP。' % candidate[:8]
        if task_id == 'MIG-ACP-PERMISSIONS-006':
            task['next_action'] = '一次性 permission wire、native Event cancellation、真实工具/next-model/late grant/close/EOF 和实际解压六进程在 clean candidate %s 有界验收；继续实际 MCP/HTTP/SSE/supervisor/subagent；完整 ACP 未认证。' % candidate[:8]
        changes.append({'path': task_path.relative_to(ROOT).as_posix(), 'value': task})
    write_json(ROOT / '.goose/out/acp-a4-work/task-changes.json', changes)
    write_json(ROOT / '.goose/out/acp-a4-work/acceptance-collection.json', {'product_commit': candidate,
        'archive_sha256': summary['archive_sha256'], 'bundle': artifact, 'created_evidence': created,
        'regression': counts, 'source_counts': source_counts, 'product_inputs': len(product_inputs),
        'bounded_inputs': len(backend_inputs)})
    print(json.dumps({'candidate': candidate, 'bundle': artifact, 'evidence_count': len(created)}))


if __name__ == '__main__':
    main()
