import asyncio
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from dsh.core.abort import AbortController
from rpc import ABSENT, AcpRpc, RequestError


async def settled():
    for iteration in range(100):
        await asyncio.sleep(0)


async def main():
    observations = []
    for mode in ['result', 'remote-error', 'invalid', 'unknown', 'preabort', 'cancel', 'close', 'write-failure', 'mapper']:
        output = []
        def write(frame):
            output.append(json.loads(frame))
            if mode == 'write-failure':
                raise RuntimeError('write fixture failure')
        rpc = AcpRpc(write)
        controller = AbortController()
        if mode == 'preabort':
            controller.abort('fixture cancellation')
        def mapper(value):
            if mode == 'mapper':
                raise RuntimeError('mapper fixture failure')
            return {'mapped': value}
        pending = rpc.request('fixture/request', {'value': '中文'}, controller.signal, mapper)
        await settled()
        if mode == 'cancel':
            controller.abort('fixture cancellation')
            await settled()
        if mode == 'unknown':
            rpc.data('{"jsonrpc":"2.0","id":"0","result":"ignored"}\n')
            await settled()
        before = pending.done()
        if mode == 'close':
            rpc.end()
        elif mode != 'write-failure':
            packet = {'jsonrpc': '2.0', 'id': 0}
            if mode == 'remote-error':
                packet['error'] = {'code': -32602, 'message': 'fixture rejected', 'data': {'value': False}}
            elif mode == 'invalid':
                packet.update(result='ambiguous', error={'code': -32603, 'message': 'invalid'})
            else:
                packet['result'] = 'accepted'
            rpc.data(json.dumps(packet) + '\n')
        try:
            outcome = {'value': await pending}
        except Exception as error:
            outcome = {'error': {'message': str(error)}}
            if isinstance(error, RequestError):
                outcome['error']['code'] = error.code
                if error.data is not ABSENT:
                    outcome['error']['data'] = error.data
        await settled()
        observations.append(dict(mode=mode, output=output, settledBeforeReply=before, outcome=outcome, closed=rpc.closed))
        rpc.close()
        await rpc.drain()
    Path(sys.argv[1]).write_text(json.dumps(observations, ensure_ascii=False, indent=2), encoding='utf-8')


asyncio.run(main())
