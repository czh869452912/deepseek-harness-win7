import asyncio
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from dsh.mcp.transport import StdioMcpTransport


async def main():
    transport = StdioMcpTransport(str(ROOT / '.goose/out/acp-a4-work/no-such-executable.exe'))
    observation = {}
    try:
        await transport.connect()
        observation.update(connected=True, actualProcess=transport.proc is not None)
    except Exception as error:
        observation.update(connected=False, error=str(error))
    try:
        observation['tools'] = await transport.list_tools()
    except Exception as error:
        observation['toolsError'] = str(error)
    try:
        observation['call'] = await transport.call_tool('unlisted', {})
    except Exception as error:
        observation['callError'] = str(error)
    await transport.close()
    (ROOT / '.goose/out/acp-a4-work/mcp-provider-python.json').write_text(json.dumps(observation, indent=2), encoding='utf-8')


asyncio.run(main())
