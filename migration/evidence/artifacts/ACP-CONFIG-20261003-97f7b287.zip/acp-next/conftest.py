import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
import dsh.acp

for name in ('model_control', 'content', 'updates', 'session_runtime'):
    spec = importlib.util.spec_from_file_location('dsh.acp.' + name, Path(__file__).with_name(name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
