import ctypes
from ctypes import wintypes
import json
from pathlib import Path


class ProcessIdentity(ctypes.Structure):
    _fields_ = [('process_id', wintypes.DWORD), ('start_time', wintypes.FILETIME)]


class ProcessInformation(ctypes.Structure):
    _fields_ = [('identity', ProcessIdentity), ('application', wintypes.WCHAR * 256),
        ('service', wintypes.WCHAR * 64), ('application_type', ctypes.c_int),
        ('status', wintypes.ULONG), ('session', wintypes.DWORD), ('restartable', wintypes.BOOL)]


manager = ctypes.WinDLL('rstrtmgr')
manager.RmStartSession.argtypes = [ctypes.POINTER(wintypes.DWORD), wintypes.DWORD, wintypes.LPWSTR]
manager.RmRegisterResources.argtypes = [wintypes.DWORD, wintypes.UINT, ctypes.POINTER(wintypes.LPCWSTR),
    wintypes.UINT, ctypes.POINTER(ProcessIdentity), wintypes.UINT, ctypes.POINTER(wintypes.LPCWSTR)]
manager.RmGetList.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.UINT), ctypes.POINTER(wintypes.UINT),
    ctypes.POINTER(ProcessInformation), ctypes.POINTER(wintypes.DWORD)]
manager.RmEndSession.argtypes = [wintypes.DWORD]
root = Path(__file__).resolve().parents[3]
path = root / 'migration/evidence/artifacts/CONFINED-CONSOLE-WEB-QUALIFICATION-20261007-94A34B5D.zip'
session = wintypes.DWORD()
key = ctypes.create_unicode_buffer(33)
assert manager.RmStartSession(ctypes.byref(session), 0, key) == 0
try:
    files = (wintypes.LPCWSTR * 1)(str(path))
    assert manager.RmRegisterResources(session, 1, files, 0, None, 0, None) == 0
    needed, count, reasons = wintypes.UINT(), wintypes.UINT(), wintypes.DWORD()
    result = manager.RmGetList(session, ctypes.byref(needed), ctypes.byref(count), None, ctypes.byref(reasons))
    assert result in (0, 234)
    rows = []
    if needed.value:
        count.value = needed.value
        processes = (ProcessInformation * count.value)()
        assert manager.RmGetList(session, ctypes.byref(needed), ctypes.byref(count), processes, ctypes.byref(reasons)) == 0
        rows = [dict(pid=processes[position].identity.process_id, name=processes[position].application,
            service=processes[position].service) for position in range(count.value)]
    print(json.dumps(dict(path=str(path), owners=rows), ensure_ascii=True))
finally:
    manager.RmEndSession(session)
