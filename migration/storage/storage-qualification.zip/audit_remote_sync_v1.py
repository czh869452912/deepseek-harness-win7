import collections
import json
from pathlib import Path
import subprocess


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
objects = subprocess.check_output(['git', 'rev-list', '--objects', 'origin/master..HEAD'], cwd=str(root))
metadata = subprocess.check_output(['git', 'cat-file', '--batch-check=%(objectname) %(objecttype) %(objectsize) %(rest)'],
    input=objects, cwd=str(root)).decode('utf-8')
blobs = []
for line in metadata.splitlines():
    parts = line.split(' ', 3)
    if len(parts) == 4 and parts[1] == 'blob':
        blobs.append(dict(oid=parts[0], bytes=int(parts[2]), path=parts[3]))
references = collections.defaultdict(list)
for path in (root / 'migration/evidence').glob('*.json'):
    record = json.loads(path.read_text(encoding='utf-8'))
    for artifact in record.get('artifacts', []):
        references[artifact['path']].append(dict(id=record['id'], kind=record['kind'],
            result=record['result'], validity=record['validity'], task=record.get('task_id'),
            sha256=artifact['sha256']))
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'migration/evidence/artifacts'], cwd=str(root)).decode('utf-8').split('\0')
archives = []
for name in tracked:
    if not name.endswith('.zip'):
        continue
    path = root / name
    archives.append(dict(path=name, bytes=path.stat().st_size, references=references.get(name, [])))
oversized = []
for blob in blobs:
    if blob['bytes'] > 100 * 1024 * 1024:
        oversized.append(dict(blob, references=references.get(blob['path'], [])))
oversized.sort(key=lambda row: row['bytes'], reverse=True)
archive_blobs = [row for row in blobs if row['path'].startswith('migration/evidence/artifacts/') and row['path'].endswith('.zip')]
unreferenced = [row for row in archives if not row['references']]
result = dict(productCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=str(root)).decode().strip(),
    remoteCommit=subprocess.check_output(['git', 'rev-parse', 'origin/master'], cwd=str(root)).decode().strip(),
    unpushedCommits=int(subprocess.check_output(['git', 'rev-list', '--count', 'origin/master..HEAD'], cwd=str(root))),
    newBlobCount=len(blobs), newBlobBytes=sum(row['bytes'] for row in blobs),
    lfsZipObjectCount=len(archive_blobs), lfsZipObjectBytes=sum(row['bytes'] for row in archive_blobs),
    oversizedCount=len(oversized), oversizedBytes=sum(row['bytes'] for row in oversized), oversized=oversized,
    currentArchiveCount=len(archives), currentArchiveBytes=sum(row['bytes'] for row in archives),
    unreferencedArchiveCount=len(unreferenced), unreferencedArchiveBytes=sum(row['bytes'] for row in unreferenced),
    unreferencedArchives=unreferenced,
    caution='Unreferenced by direct JSON artifacts is not deletion permission: docs, nested archives, original failures and reconstruction dependencies still require examination. Historical/stale-input acceptance is not expired raw evidence. No history rewrite, deletion or upload performed.')
output = work / 'remote-sync-audit-v1.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=True, indent=2)
    stream.write('\n')
print(json.dumps({name: value for name, value in result.items()
    if name not in ('oversized', 'unreferencedArchives')}, ensure_ascii=True, indent=2))
print(json.dumps([dict(path=row['path'], bytes=row['bytes'], referenceCount=len(row['references']),
    kinds=sorted({ref['kind'] for ref in row['references']})) for row in oversized], indent=2))
