import asyncio
import base64
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from rpc import ABSENT, AcpRpc


async def main():
    observations = []
    for case in json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')):
        output = []
        rpc = AcpRpc(lambda frame: output.append(json.loads(frame)))
        rpc.handlers['echo'] = lambda params, signal: None if params is ABSENT else params
        for byte in base64.b64decode(case['bytes']):
            rpc.data(bytes([byte]))
        for iteration in range(300):
            await asyncio.sleep(0)
        rpc.end()
        await rpc.reader
        await rpc.drain()
        observations.append({'mode': case['mode'], 'output': output})
    Path(sys.argv[2]).write_text(json.dumps(observations, ensure_ascii=True, indent=2), encoding='utf-8')


asyncio.run(main())
