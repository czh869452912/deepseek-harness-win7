import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request


root = Path(__file__).resolve().parents[3]
manifest = json.loads((root / 'migration/storage/lfs-transport.json').read_text(encoding='utf-8'))
credentials = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\npath=czh869452912/deepseek-harness-win7.git\n\n', encoding='utf-8', stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
fields = dict(line.split('=', 1) for line in credentials.stdout.splitlines() if '=' in line)
authorization = base64.b64encode((fields['username'] + ':' + fields['password']).encode('utf-8')).decode('ascii')
endpoint = 'https://github.com/czh869452912/deepseek-harness-win7.git/info/lfs/objects/batch'
output = root / '.goose/out/acp-a4-work/remote-lfs-download-verification-v1.json'
started = time.perf_counter()
record = dict(operation='Full remote LFS download, streamed without retaining duplicate data; verify SHA256 and original Git blob SHA1.', files=[], failures=[])


def verify_download(arguments):
    archive, actual = arguments
    try:
        assert actual['oid'] == archive['sha256'] and actual['size'] == archive['size']
        action = actual['actions']['download']
        assert action['href'].startswith('https://')
        request = urllib.request.Request(action['href'], headers=action.get('header', {}))
        content = hashlib.sha256()
        blob = hashlib.sha1(b'blob ' + str(archive['size']).encode('ascii') + b'\0')
        size = 0
        with urllib.request.urlopen(request, timeout=60) as response:
            while True:
                block = response.read(1048576)
                if not block:
                    break
                size += len(block)
                assert size <= archive['size']
                content.update(block)
                blob.update(block)
        assert size == archive['size'] and content.hexdigest() == archive['sha256'] and blob.hexdigest() == archive['git_blob']
        return dict(path=archive['path'], size=size, sha256=content.hexdigest(), git_blob=blob.hexdigest(), verified=True)
    except Exception as error:
        return dict(path=archive['path'], verified=False, type=type(error).__name__, http_status=error.code if isinstance(error, urllib.error.HTTPError) else None)


with ThreadPoolExecutor(max_workers=3) as pool:
    for start in range(0, len(manifest['archives']), 5):
        archives = manifest['archives'][start:start + 5]
        body = json.dumps(dict(operation='download', transfers=['basic'], objects=[dict(oid=entry['sha256'], size=entry['size']) for entry in archives])).encode('utf-8')
        request = urllib.request.Request(endpoint, data=body, headers={'Authorization': 'Basic ' + authorization, 'Accept': 'application/vnd.git-lfs+json', 'Content-Type': 'application/vnd.git-lfs+json'})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                received = {entry['oid']: entry for entry in json.load(response)['objects']}
            for result in pool.map(verify_download, [(archive, received[archive['sha256']]) for archive in archives]):
                record['files' if result['verified'] else 'failures'].append(result)
                print(json.dumps(dict(path=result['path'], verified=result['verified'], completed=len(record['files']), seconds=round(time.perf_counter() - started, 2))), flush=True)
                output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        except Exception as error:
            record['failures'].append(dict(batch=start // 5, type=type(error).__name__, http_status=error.code if isinstance(error, urllib.error.HTTPError) else None))
            print(json.dumps(record['failures'][-1]), flush=True)
            break
record.update(complete=len(record['files']) == len(manifest['archives']) and not record['failures'], seconds=time.perf_counter() - started, verified_bytes=sum(entry['size'] for entry in record['files']))
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({name: value for name, value in record.items() if name not in ('files', 'failures')}), flush=True)
