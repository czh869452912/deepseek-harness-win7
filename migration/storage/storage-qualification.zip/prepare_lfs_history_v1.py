import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from scripts import migration_storage as storage


def git(*args):
    return subprocess.check_output(['git', '-C', str(root)] + list(args), encoding='utf-8').strip()


assert not git('status', '--porcelain')
output = work / 'lfs-preserved-inputs-v1.json'
assert not output.exists()
original_tip = git('rev-parse', 'HEAD')
remote_base = git('rev-parse', 'origin/master')
backup = root / '.goose/out/lfs-original-history-20261007.git'
assert subprocess.check_output(['git', '-C', str(backup), 'rev-parse', 'HEAD'], encoding='ascii').strip() == original_tip
assert not (backup / 'objects/info/alternates').exists()
commits = git('rev-list', '--reverse', 'origin/master..HEAD').splitlines()
reader = storage.GitObjects(root)
original_objects = {}


def collect_tree(oid):
    if ('tree', oid) in original_objects:
        return
    body = reader.read(oid, 'tree')
    original_objects['tree', oid] = body
    for name, (mode, child) in storage.tree_entries(body).items():
        if mode == b'40000':
            collect_tree(child)
        elif name == b'.gitattributes':
            original_objects['blob', child] = reader.read(child, 'blob')


try:
    for commit in commits:
        body = reader.read(commit, 'commit')
        original_objects['commit', commit] = body
        collect_tree(storage.commit_parts(body)[0])
finally:
    reader.close()
metadata = work / 'lfs-original-git-metadata-v1.zip'
with zipfile.ZipFile(str(metadata), 'x', zipfile.ZIP_DEFLATED) as archive:
    for (kind, oid), body in sorted(original_objects.items()):
        archive.writestr(kind + '/' + oid, body)
with zipfile.ZipFile(str(metadata)) as archive:
    assert archive.testzip() is None
    for information in archive.infolist():
        kind, oid = information.filename.split('/')
        assert storage.object_id(kind, archive.read(information)) == oid
indexed = subprocess.check_output(['git', '-C', str(root), 'ls-files', '-s', '-z', '--',
    'migration/evidence/artifacts/*.zip']).decode('utf-8').split('\0')
archives = []
for position, entry in enumerate(row for row in indexed if row):
    identity, name = entry.split('\t', 1)
    mode, oid, stage = identity.split()
    assert mode == '100644' and stage == '0'
    path = storage.owned_file(root, name)
    size, original_blob, digest = storage.file_digests(path)
    assert original_blob == oid
    cached = root / '.git/lfs/objects' / digest[:2] / digest[2:4] / digest
    cached.parent.mkdir(parents=True, exist_ok=True)
    if cached.exists():
        assert storage.file_digests(cached) == (size, oid, digest)
    else:
        os.link(str(path), str(cached))
    assert os.path.samefile(str(path), str(cached)) or storage.file_digests(cached) == (size, oid, digest)
    archives.append(dict(path=name, git_blob=oid, sha256=digest, size=size))
    print(json.dumps(dict(position=position, path=name, bytes=size, cached=True)), flush=True)
assert git('rev-parse', 'HEAD') == original_tip and not git('status', '--porcelain')
record = dict(original_tip=original_tip, remote_base=remote_base, commits=commits,
    original_metadata=str(metadata), objects_sha256=hashlib.sha256(metadata.read_bytes()).hexdigest(),
    metadata_objects=len(original_objects), archives=archives, backup=str(backup),
    backup_type='Self-contained bare Git backup with hardlinks to immutable Git objects on the same NTFS volume; no alternates. Protect from process artifact cleanup.',
    free_bytes=shutil.disk_usage(str(root)).free)
with output.open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(original_tip=original_tip, remote_base=remote_base, commits=len(commits),
    metadata_objects=len(original_objects), metadata_bytes=metadata.stat().st_size,
    archives=len(archives), archive_bytes=sum(row['size'] for row in archives), free_bytes=record['free_bytes'])), flush=True)
