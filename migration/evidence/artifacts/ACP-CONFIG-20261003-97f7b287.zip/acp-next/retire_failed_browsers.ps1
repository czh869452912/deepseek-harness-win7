$taskTempRoot = [IO.Path]::GetFullPath($env:TEMP).TrimEnd('\')
$ownedTargets = Get-Content -LiteralPath '.goose/out/acp-next/failed-owned-browser-paths.json' -Encoding utf8 -Raw | ConvertFrom-Json
$audit = @()
foreach ($directory in $ownedTargets) {
    $resolvedTarget = [IO.Path]::GetFullPath($directory)
    if ([IO.Path]::GetDirectoryName($resolvedTarget) -ne $taskTempRoot) { throw 'Outside test temp parent' }
    if ([IO.Path]::GetFileName($resolvedTarget) -notmatch '^dsh-(web-package-cdp|cdp)-[A-Za-z0-9]+$') { throw 'Unrecognized owned test profile' }
    $profilePattern = [regex]::Escape($resolvedTarget) + '(?=["\s]|$)'
    $ownedProcesses = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'msedge.exe' -and $_.CommandLine -match $profilePattern }
    foreach ($ownedProcess in $ownedProcesses) {
        $currentProcess = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $ownedProcess.ProcessId)
        if ($currentProcess -and $currentProcess.Name -eq 'msedge.exe' -and $currentProcess.CommandLine -match $profilePattern) {
            $audit += @{ directory=$resolvedTarget; processId=$currentProcess.ProcessId; parentProcessId=$currentProcess.ParentProcessId }
            Stop-Process -Id $currentProcess.ProcessId -Force -ErrorAction SilentlyContinue
        }
    }
}
$audit | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath '.goose/out/acp-next/failed-owned-browser-retirement.json' -Encoding utf8
Write-Output ('Retired exact failed-test browser processes: ' + $audit.Count)
