import * as source from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/schema/zod.gen.js';
import {writeFileSync} from 'node:fs';

function fallback(value) {
  return value === undefined ? {absent: true} : typeof value === 'symbol' ? {skip: true} : {value};
}
function exportSchema(schema) {
  const definition = schema._zod.def;
  const result = {type: definition.type};
  switch (definition.type) {
    case 'object':
      result.shape = Object.fromEntries(Object.entries(definition.shape).map(([name, field]) => [name, exportSchema(field)]));
      break;
    case 'optional': case 'nullable':
      result.inner = exportSchema(definition.innerType);
      break;
    case 'catch':
      result.inner = exportSchema(definition.innerType);
      result.fallback = fallback(definition.catchValue({input: undefined, error: {issues: []}}));
      break;
    case 'default':
      result.inner = exportSchema(definition.innerType);
      result.fallback = fallback(definition.defaultValue);
      break;
    case 'array':
      result.element = exportSchema(definition.element);
      break;
    case 'record':
      result.key = exportSchema(definition.keyType);
      result.value = exportSchema(definition.valueType);
      break;
    case 'union':
      result.options = definition.options.map(exportSchema);
      break;
    case 'intersection':
      result.left = exportSchema(definition.left);
      result.right = exportSchema(definition.right);
      break;
    case 'literal':
      result.values = definition.values;
      break;
    case 'enum':
      result.values = Object.values(definition.entries);
      break;
    case 'number':
      if (definition.format) result.format = definition.format;
      result.checks = (definition.checks ?? []).map(check => check._zod.def);
      break;
    case 'pipe': {
      const transform = String(definition.out._zod.def.transform);
      if (transform.includes('items.filter')) {
        result.type = 'skip-array';
        result.inner = exportSchema(definition.in);
      } else if (transform.includes('Required value is missing')) {
        result.type = 'required-mcp-array';
        result.element = exportSchema(source.zMcpServer);
      } else throw new Error('Unsupported transform: ' + transform);
      break;
    }
    case 'unknown': case 'string': case 'boolean':
      break;
    default: throw new Error('Unsupported schema: ' + definition.type);
  }
  return result;
}
const names = {
  initialize: 'zInitializeRequest', authenticate: 'zAuthenticateRequest',
  'session/new': 'zNewSessionRequest', 'session/list': 'zListSessionsRequest',
  'session/resume': 'zResumeSessionRequest', 'session/close': 'zCloseSessionRequest',
  'session/set_config_option': 'zSetSessionConfigOptionRequest', 'session/prompt': 'zPromptRequest',
  'session/cancel': 'zCancelNotification',
};
writeFileSync(process.argv[2], JSON.stringify(Object.fromEntries(Object.entries(names).map(([method, name]) => [method, exportSchema(source[name])])), null, 2));
