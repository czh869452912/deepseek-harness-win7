import { Client } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import { StdioClientTransport } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const client = new Client({name: 'migration-negative-observer', version: '1.0.0'});
const transport = new StdioClientTransport({command: resolve('.goose/out/acp-a4-work/no-such-executable.exe'), args: [], env: {}, stderr: 'pipe'});
const observation = {};
try {await client.connect(transport); observation.connected = true;}
catch (error) {observation.connected = false; observation.error = String(error.message);}
try {observation.tools = await client.listTools();}
catch (error) {observation.toolsError = String(error.message);}
try {observation.call = await client.callTool({name: 'unlisted', arguments: {}});}
catch (error) {observation.callError = String(error.message);}
await client.close();
writeFileSync('.goose/out/acp-a4-work/mcp-provider-source.json', JSON.stringify(observation, null, 2));
