import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from params import ABSENT, validate_params
from rpc import RequestError


results = []
for case in json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')):
    try:
        results.append({'mode': case['mode'], 'value': validate_params(case['method'], case.get('params', ABSENT))})
    except RequestError as error:
        results.append({'mode': case['mode'], **error.result()})
Path(sys.argv[2]).write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
