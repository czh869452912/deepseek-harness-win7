import * as schemas from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/schema/zod.gen.js';
function inspect(schema, depth=0) {
  const definition=schema._zod.def;
  const value={type:definition.type, keys:Object.keys(definition)};
  if(definition.checks) value.checks=definition.checks.map(check=>check._zod.def);
  if(definition.type==='pipe') {value.from=definition.in._zod.def.type;value.to=definition.out._zod.def.type;value.transform=String(definition.out._zod.def.transform)}
  console.log(JSON.stringify(value));
  if(depth<2 && definition.shape) for(const [name,field] of Object.entries(definition.shape)) {console.log(name);inspect(field,depth+1)}
  if(depth<2 && definition.innerType) inspect(definition.innerType,depth+1);
}
for(const name of ['zInitializeRequest','zNewSessionRequest','zContentBlock','zClientCapabilities','zProtocolVersion']) {console.log(name);inspect(schemas[name])}
