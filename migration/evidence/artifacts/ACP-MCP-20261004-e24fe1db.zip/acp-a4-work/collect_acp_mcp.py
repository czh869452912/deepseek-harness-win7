import hashlib
from datetime import datetime
import json
import platform
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
import migration
import verify_release


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    assert len(sys.argv) == 3, 'expected clean output directory and candidate SHA'
    output = ROOT / sys.argv[1]
    summary = json.loads((output / 'summary.json').read_text(encoding='utf-8'))
    assert summary['result'] == 'passed' and summary['publishable'] is True and summary['worktree_dirty'] is False
    candidate = summary['product_commit']
    assert candidate == sys.argv[2] and len(candidate) == 40
    assert verify_release.git('rev-parse', 'HEAD') == candidate and not verify_release.git('status', '--porcelain')
    frozen = json.loads((output / 'inputs.json').read_text(encoding='utf-8'))
    assert frozen == verify_release.source_snapshot()
    assert digest(output / 'inputs.json') == summary['input_manifest_sha256']
    archive_path = Path(summary['archive'])
    assert digest(archive_path) == summary['archive_sha256']
    for name, expected in summary['receipts'].items():
        assert digest(output / (name + '.json')) == expected, name
    counts = ET.parse(str(output / 'pytest.xml')).getroot().find('testsuite').attrib
    assert counts['failures'] == '0' and counts['errors'] == '0'
    assert summary['regression']['required_lanes'] == 62
    assert len(verify_release.PAIRED_DRIVERS) == 31
    source_counts = {}
    expected_counts = {'consumers': 80, 'agent-lifecycle': 100, 'session-recovery': 197,
                       'session-projection': 100, 'acp': 139, 'acp-app': 3, 'mcp': 103}
    assert set(verify_release.OFFICIAL_CONFIGS) == set(expected_counts)
    for config in verify_release.OFFICIAL_CONFIGS:
        log = (output / ('official-' + config + '.log')).read_text(encoding='utf-8')
        matches = re.findall(r'Tests\s+(\d+) passed', re.sub(r'\x1b\[[0-9;]*m', '', log))
        assert matches == [str(expected_counts[config])], (config, matches)
        source_counts[config] = expected_counts[config]
    verify_release.validate_extracted(output / 'portable-extracted.json', archive_path, summary)
    tasks = ['MIG-CURRENT-RELEASE-GATE-003', 'MIG-ACP-PROMPT-OWNERSHIP-001',
        'MIG-CORDIS-001', 'MIG-AGENT-LIFECYCLE-002', 'MIG-AGENT-CONFIG-003',
        'MIG-SESSION-COLD-003', 'MIG-SESSION-LIVE-004', 'MIG-SESSION-PREPARED-005',
        'MIG-SESSION-STORAGE-006', 'MIG-SESSION-PROJECTION-007', 'MIG-SPINE-001',
        'MIG-PORTABLE-001', 'MIG-ACP-SESSION-CONTROLS-003', 'MIG-ACP-CONFIG-OUTPUT-004',
        'MIG-ACP-STDIO-005', 'MIG-ACP-PERMISSIONS-006', 'MIG-MCP-STDIO-007', 'MIG-MCP-HTTP-008', 'MIG-ACP-MCP-009']
    stamp = datetime.now().strftime('%Y%m%d')
    bundle = ROOT / ('migration/evidence/artifacts/ACP-MCP-' + stamp + '-' + candidate[:8] + '.zip')
    directories = [output, ROOT / '.goose/out/acp-mcp-owned-preview', ROOT / '.goose/out/acp-a4-work']
    with zipfile.ZipFile(str(bundle), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for directory in directories:
            assert directory.is_dir(), directory
            for path in sorted(directory.rglob('*')):
                if any(part in ('vite-cache', 'mcp-vite-cache', '__pycache__', 'node_modules')
                       for part in path.relative_to(directory).parts):
                    continue
                if path.is_file():
                    archive.write(str(path), directory.name + '/' + path.relative_to(directory).as_posix())
    with zipfile.ZipFile(str(bundle)) as archive:
        assert archive.testzip() is None
        for name, expected in summary['receipts'].items():
            assert hashlib.sha256(archive.read(output.name + '/' + name + '.json')).hexdigest() == expected
    product_inputs = {name: value for name, value in frozen.items() if not name.startswith(('migration/', 'docs/'))}
    backend_inputs = {name: value for name, value in product_inputs.items() if not name.startswith('packages/')}
    frontend = json.loads((ROOT / 'scripts/frontend-inputs.json').read_text(encoding='utf-8'))
    assert len(frontend['files']) == 119
    for item in frontend['files']:
        assert frozen[item['path']] == item['sha256']
        backend_inputs[item['path']] = item['sha256']
    artifact = {'path': bundle.relative_to(ROOT).as_posix(), 'sha256': digest(bundle)}
    passed = int(counts['tests']) - int(counts['skipped'])
    changes, created = [], []
    for task_id in tasks:
        task_path = ROOT / 'migration/tasks' / (task_id + '.json')
        task = json.loads(task_path.read_text(encoding='utf-8'))
        evidence_id = 'RUN-ACP-MCP-' + stamp + '-' + task_id[len('MIG-'):]
        selected = product_inputs if task_id == tasks[0] else backend_inputs
        record = {'id': evidence_id, 'target_upstream': summary['target_upstream'],
            'product_commit': candidate, 'kind': 'acceptance', 'task_id': task_id,
            'acceptance_digest': migration.acceptance_digest(task), 'result': 'passed', 'validity': 'current',
            'exit_code': 0, 'commands': ['.venv/Scripts/python.exe scripts/verify_release.py --browser "'
                + summary['browser'] + '" --output-dir .goose/out/' + output.name],
            'environment': {'python': summary['python'], 'os': platform.platform(), 'cwd': str(ROOT),
                            'node': summary['node'], 'browser': summary['browser']},
            'contract_revisions': {item['contract']: item['revision'] for item in task['provides'] + task['requires']},
            'inputs': [{'path': name, 'sha256': selected[name]} for name in sorted(selected)],
            'artifacts': [artifact], 'scope': ('Clean current-Windows candidate; %d passed, %s platform skips, '
                '62 required lanes, 722 unchanged source assertions, 31 selected paired drivers, actual extracted '
                'ZIP with 20 raw stdio and 16 HTTP observations, real ToolsService consumers and canonical ACP '
                'MCP process (three proved stdio exits, one HTTP consumer, eight local model requests). Only this task '
                'bounded contract is accepted. Remaining SDK HTTP/supervisor/URL edges, infinite blocked ACP '
                'initialization, subprocess subagent, B/C/D, '
                'fresh uncached bootstrap, remote Actions, paid models and deferred Win7 remain unaccepted. '
                'Earlier failed previews and browser startup cancellation are preserved; this passing run does '
                'not prove the browser, Proactor warning or HTTP 10054 root cause fixed. Isolated subagent prototypes '
                'archived as diagnostics are not part of this clean candidate acceptance.') % (passed, counts['skipped'])}
        write_json(ROOT / 'migration/evidence' / (evidence_id + '.json'), record)
        task.update(state='integrated', candidate_commit=candidate, integrated_commit=candidate, open_findings=[])
        task['evidence_ids'].append(evidence_id)
        if task_id in ('MIG-MCP-STDIO-007', 'MIG-MCP-HTTP-008', 'MIG-ACP-MCP-009'):
            task['next_action'] = '有界提供端合同在 clean candidate %s 验收；继续其余 SDK/生命周期/URL/无限阻塞初始化边缘、subprocess subagent 和整体迁移。既有浏览器/Proactor/HTTP 诊断未修复，Win7 仍延期。' % candidate[:8]
        elif task_id == tasks[0]:
            task['next_action'] = 'clean candidate %s 当前 Windows 完整门禁通过；62 必需 lane、722 原版断言、31 配对及实际 Portable，不认证全量迁移或 Win7。' % candidate[:8]
        changes.append({'path': task_path.relative_to(ROOT).as_posix(), 'value': task})
        created.append(evidence_id)
    write_json(ROOT / '.goose/out/acp-a4-work/acp-mcp-task-changes.json', changes)
    write_json(ROOT / '.goose/out/acp-a4-work/acp-mcp-acceptance-collection.json', {'product_commit': candidate,
        'archive_sha256': summary['archive_sha256'], 'bundle': artifact, 'created_evidence': created,
        'regression': counts, 'source_counts': source_counts, 'product_inputs': len(product_inputs),
        'bounded_inputs': len(backend_inputs)})
    print(json.dumps({'candidate': candidate, 'bundle': artifact, 'evidence_count': len(created)}))


if __name__ == '__main__':
    main()
