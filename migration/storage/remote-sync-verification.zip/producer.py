import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import zipfile


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
regression = root / '.goose/out/lfs-storage-full-regression-v1'
summary = json.loads((regression / 'summary.json').read_text(encoding='utf-8'))
download = json.loads((work / 'remote-lfs-download-verification-v1.json').read_text(encoding='utf-8'))
clone = json.loads((work / 'remote-clone-verification-v1.json').read_text(encoding='utf-8'))
assert download['complete'] and len(download['files']) == 86 and download['verified_bytes'] == 6910079579
assert clone['result'] == 'passed' and clone['original_commit_absent'] and clone['no_alternates']
assert subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], encoding='ascii').strip() == summary['product_commit'] == clone['head']
assert not subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain']).strip()
assert subprocess.check_output(['git', '-C', str(root), 'ls-remote', '--heads', 'origin', 'master'], encoding='ascii').split()[0] == clone['head']
spec = importlib.util.spec_from_file_location('remote_sync_final_snapshot', root / 'scripts/verify_release.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
assert gate.source_snapshot() == json.loads((regression / 'inputs.json').read_text(encoding='utf-8'))
diagnostic = dict(tested_head=summary['product_commit'], frozen_snapshot_unchanged=True, remote_head=clone['head'], remote_download_verified=86, remote_bytes=download['verified_bytes'], clone_without_original_objects=True, full_regression=summary, scope='Full source/evidence sync verified. Complete direct pytest run outcome retained independently; not complete release acceptance or upstream parity.')
(work / 'remote-sync-final-summary-v1.json').write_text(json.dumps(diagnostic, indent=2) + '\n', encoding='utf-8')
sources = {name: work / name for name in ('check_remote_lfs_v1.py', 'remote-lfs-availability-v1.json', 'download_verify_remote_lfs_v1.py', 'remote-lfs-download-verification-v1.json', 'remote-lfs-download-verification-v1.log', 'remote-git-push-receipt-v1.json', 'verify_remote_clone_v1.py', 'remote-clone-verification-v1.json', 'remote-clone-verification-v1.log', 'remote-clone-migration-check-v1.log', 'remote-clone-git-fsck-v1.log', 'run_lfs_full_regression_v1.py', 'lfs-storage-full-regression-driver-v1.log', 'remote-sync-final-summary-v1.json')}
sources['producer.py'] = Path(__file__)
sources['remote-clone-cleanup-refusal-v1.json'] = work / 'remote-clone-cleanup-refusal-v1.json'
for path in regression.iterdir():
    if path.is_file():
        assert path.stat().st_size < 20 * 1024 * 1024
        sources['full-regression/' + path.name] = path
members = {name: dict(size=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name, path in sources.items()}
archive_path = root / 'migration/storage/remote-sync-verification.zip'
with zipfile.ZipFile(str(archive_path), 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sources.items():
        archive.write(str(path), name)
    archive.writestr('manifest.json', json.dumps(dict(members=members, verification=diagnostic, exclusions='No signed/authentication URLs or credentials; no duplicate large archives. Raw failed pytest workspace remains locally retained and is not represented as a successful suite.'), indent=2) + '\n')
with zipfile.ZipFile(str(archive_path)) as archive:
    assert archive.testzip() is None
    for name, expected in members.items():
        body = archive.read(name)
        assert len(body) == expected['size'] and hashlib.sha256(body).hexdigest() == expected['sha256']
archive_digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
shared = dict(target_upstream=clone['upstream'], product_commit=clone['head'], kind='verification', task_id='MIG-CURRENT-RELEASE-GATE-003', validity='current', environment=dict(python='3.8.10', git_lfs='3.5.1', os='Windows-10-10.0.26200-SP0'), contract_revisions={}, artifacts=[dict(path=archive_path.relative_to(root).as_posix(), sha256=archive_digest)])
records = [dict(shared, id='RUN-REMOTE-LFS-SYNC-20261007-B529A990', result='passed', exit_code=0, commands=['git lfs push --all origin master', 'git push origin master', 'Remote LFS batch download for all 86 OIDs; streamed 6910079579 bytes and verified SHA256 and original Git blob SHA1', 'Independent remote clone without alternates or original commit objects: full mapped history/archive proof and migration check'], scope='All master code/history and evidence synced through ordinary fast-forward. Original published anchor unchanged. Upload, remote availability, full actual streamed download and independent clone verified. Local clone archive materialization used verified immutable hardlinks to avoid duplicates. Server lock API/HTTP502/GH009 refusals were transient and not product/Source exceptions; successful retry follows exact uploaded OID verification. No new migration closure or complete release acceptance.'), dict(shared, id='RUN-LFS-FULL-REGRESSION-20261007-B529A990', result=summary['result'], commands=['.venv/Scripts/python.exe -m pytest tests -ra --junitxml --basetemp through unchanged run_python_regression; normal 3600-second budget'], scope='Complete direct test suite over frozen clean b529a990 storage-converted tree. Exact outcome, timing, logs, inputs and available XML retained in archive. Not full paired/Source/extracted/browser release acceptance.', regression_summary=summary)]
for record in records:
    path = root / ('migration/evidence/' + record['id'] + '.json')
    assert not path.exists()
    path.write_bytes((json.dumps(record, indent=2) + '\n').encode('utf-8'))
print(json.dumps(dict(path=archive_path.relative_to(root).as_posix(), sha256=archive_digest, size=archive_path.stat().st_size, members=len(members) + 1, regression=summary['result'])), flush=True)
