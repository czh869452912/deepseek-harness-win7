import json,os,sys
for line in sys.stdin:
    packet=json.loads(line)
    method=packet.get("method")
    if method=="notifications/initialized":
        print(json.dumps({"jsonrpc":"2.0","method":"notifications/tools/list_changed"}),flush=True)
    if "id" not in packet:
        continue
    reply={"jsonrpc":"2.0","id":packet["id"]}
    if method=="initialize":
        reply["result"]={"protocolVersion":os.environ.get("MCP_VERSION","2025-11-25"),
            "capabilities":{"tools":{}},"serverInfo":{"name":"controlled","version":"1.0"}}
    elif method=="tools/list":
        reply["result"]={"tools":[{"name":"echo","inputSchema":{"type":"object"}}]}
    elif method=="tools/call":
        args=packet["params"]["arguments"]
        if args.get("wait"):
            continue
        if args.get("error"):
            reply["error"]={"code":-32602,"message":"controlled rejection","data":{"invalid":True}}
        else:
            reply["result"]={"content":[{"type":"text","text":args.get("text","echo")}],
                "structuredContent":{"inherited":os.environ.get("CONTROLLED_API_KEY"),
                    "explicit":os.environ.get("EXPLICIT_TOKEN"),"stale":os.environ.get("DSH_STALE")}}
    else:
        reply["result"]={}
    print(json.dumps(reply),flush=True)
