import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback


root = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(root))
spec = importlib.util.spec_from_file_location('lfs_full_regression_gate', root / 'scripts/verify_release.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
output = root / '.goose/out/lfs-storage-full-regression-v1'
assert not output.exists()
assert not subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain']).strip()
output.mkdir()
commit = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], encoding='ascii').strip()
before = gate.source_snapshot()
(output / 'inputs.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
started = time.perf_counter()
record = dict(result='running', product_commit=commit, scope='Complete direct pytest tests over frozen storage-converted checkout; normal 3600 seconds. Not complete release acceptance.')
try:
    environment = gate.release_environment(Path('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'))
    gate.run_python_regression(str(root / '.venv/Scripts/python.exe'), output, environment)
    assert subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], encoding='ascii').strip() == commit
    assert gate.source_snapshot() == before
    record['result'] = 'passed'
except BaseException as error:
    record.update(result='failed', failure=dict(name=type(error).__name__, message=str(error)), traceback=traceback.format_exc())
    raise
finally:
    record['seconds'] = time.perf_counter() - started
    record['xml_complete'] = (output / 'pytest.xml').exists()
    (output / 'summary.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({name: value for name, value in record.items() if name != 'traceback'}), flush=True)
