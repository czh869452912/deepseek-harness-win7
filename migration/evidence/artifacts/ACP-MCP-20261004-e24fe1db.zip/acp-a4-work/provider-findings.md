# A4 actual provider negative probe

Pinned SDK `@modelcontextprotocol/sdk@1.29.0`, current upstream unchanged. Executed stdio nonexistent absolute executable with empty explicit env; no real credentials or network.

Source SDK Client: connect rejected `MCP error -32000: Connection closed`; subsequent tools/list and tools/call rejected `Not connected`.
Current Python StdioMcpTransport: connect fulfilled with proc=None; tools/list returned []; calling never-listed `unlisted` returned invented text `Called tool 'unlisted'`.
Raw source/python JSON and two independent observers are beside this file. They are failed parity evidence, never acceptance.

Required closure: mount actual MCP provider before publishing the exact Agent; valid schema/defaults and normalized namespaces; wire initialize/notifications/ids/remote errors; stdio process and Streamable HTTP JSON/SSE; credential-scrubbed subprocess env; synchronized paginated tools/call and update notifications; disposal while spawn/handshake/read pending; no late registration/reconnect; initial ready failure must roll back complete Agent transaction. A scoped client namespace must permit the same server name in independent Agent scopes while rejecting conflicts in the same Tools service.

Permissions: actual ACP conn.request('session/request_permission'), wait record.drainUpdates before request, exact Agent/Session/callId, allow-once only, unknown choice rejected, cancellation and client failure fail closed; same-id foreign Agent delegates. Current bridge passes through all approvals, so it is not accepted A4 policy.

Subagent ACP: no current class table provider. Existing in-process/browser consumers do not prove ACP subprocess/EOF/escalation, child cwd/env/permission or observer-scoped lifecycle. Remains a separate necessary consumer of A3 rather than a test filename count.
