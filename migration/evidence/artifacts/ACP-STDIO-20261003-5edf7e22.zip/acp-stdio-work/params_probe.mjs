import * as source from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/schema/zod.gen.js';
import {readFileSync, writeFileSync} from 'node:fs';

const names = {
  initialize: 'zInitializeRequest', authenticate: 'zAuthenticateRequest',
  'session/new': 'zNewSessionRequest', 'session/list': 'zListSessionsRequest',
  'session/resume': 'zResumeSessionRequest', 'session/close': 'zCloseSessionRequest',
  'session/set_config_option': 'zSetSessionConfigOptionRequest', 'session/prompt': 'zPromptRequest',
  'session/cancel': 'zCancelNotification',
};
const results = JSON.parse(readFileSync(process.argv[2], 'utf8')).map(({mode, method, params}) => {
  try {return {mode, value: source[names[method]].parse(params)};}
  catch (error) {return {mode, error: {code: -32602, message: 'Invalid params', data: error.format()}};}
});
writeFileSync(process.argv[3], JSON.stringify(results, null, 2));
