import { Client } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js'
import { StdioClientTransport } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js'
import { ToolListChangedNotificationSchema } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js'
import { writeFileSync } from 'node:fs'

const client = new Client({ name: 'dsh-mcp-client', version: '0.0.1' }, { capabilities: {} })
const notifications = []
client.setNotificationHandler(ToolListChangedNotificationSchema, packet => notifications.push(packet))
const transport = new StdioClientTransport({command: process.env.MCP_FIXTURE_PYTHON,
  args: ['.goose/out/acp-a4-work/mcp_stdio_fixture.py'],
  env: Object.fromEntries(Object.entries(process.env).filter(([name]) => !/KEY|PASSWORD|SECRET|TOKEN/i.test(name) && !/^DSH_/i.test(name))),
})
let result
try {
  await client.connect(transport)
  const tools = await client.listTools()
  const calls = await Promise.all(Array.from({ length: 8 }, (_, index) => client.callTool({name: 'echo', arguments: {text: String(index)}})))
  let error
  try { await client.callTool({name:'echo', arguments:{error:true}}) } catch (failure) { error = {code: failure.code, message:failure.message, data:failure.data} }
  result={protocol:'2025-11-25', server:client.getServerVersion(), tools, calls, error, notifications}
} finally {await client.close()}
writeFileSync('.goose/out/acp-a4-work/mcp-stdio-sdk.source.json',JSON.stringify(result,null,2))
