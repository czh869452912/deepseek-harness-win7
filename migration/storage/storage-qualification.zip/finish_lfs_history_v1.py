import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from scripts import migration_storage as storage


record = json.loads((work / 'lfs-preserved-inputs-v1.json').read_text(encoding='utf-8'))
mapping_path = work / 'lfs-object-map-v1.csv'
aliases = dict(csv.reader(mapping_path.read_text(encoding='utf-8').splitlines()))
assert set(aliases) == set(record['commits'])
tip = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], encoding='ascii').strip()
assert aliases[record['original_tip']] == tip
assert subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'origin/master'], encoding='ascii').strip() == record['remote_base']
reader = storage.GitObjects(root)
try:
    for row in record['archives']:
        path = root / row['path']
        cached = root / '.git/lfs/objects' / row['sha256'][:2] / row['sha256'][2:4] / row['sha256']
        assert storage.file_digests(cached) == (row['size'], row['git_blob'], row['sha256'])
        if path.exists() and os.path.samefile(str(path), str(cached)):
            continue
        if path.exists() and path.stat().st_size == row['size']:
            assert storage.file_digests(path) == (row['size'], row['git_blob'], row['sha256'])
            continue
        oid = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD:' + row['path']], encoding='ascii').strip()
        pointer = ('version https://git-lfs.github.com/spec/v1\noid sha256:' + row['sha256']
            + '\nsize ' + str(row['size']) + '\n').encode('ascii')
        assert reader.read(oid, 'blob') == pointer and path.read_bytes() == pointer
        try:
            path.unlink()
        except PermissionError as error:
            if error.winerror != 32:
                raise
            assert path.read_bytes() == pointer
            with cached.open('rb') as source, path.open('wb') as destination:
                shutil.copyfileobj(source, destination, 1048576)
            assert storage.file_digests(path) == (row['size'], row['git_blob'], row['sha256'])
            print(json.dumps(dict(path=row['path'], restoration='Verified cached bytes copied into locked pointer; original archive untouched')), flush=True)
        else:
            os.link(str(cached), str(path))
finally:
    reader.close()
folder = root / 'migration/storage'
folder.mkdir(exist_ok=True)
metadata = folder / 'original-git-metadata.zip'
assert not metadata.exists()
shutil.copyfile(record['original_metadata'], str(metadata))
mapping = folder / 'lfs-map.csv'
assert not mapping.exists()
mapping.write_text('\n'.join(mapping_path.read_text(encoding='utf-8').splitlines()) + '\n', encoding='utf-8')
manifest = dict(schema_version=1, original_tip=record['original_tip'], rewritten_tip=tip,
    remote_base=record['remote_base'], mapping_path='migration/storage/lfs-map.csv',
    mapping_sha256=hashlib.sha256(mapping.read_bytes()).hexdigest(),
    objects_path='migration/storage/original-git-metadata.zip', objects_sha256=record['objects_sha256'],
    archives=record['archives'], scope='Storage-only conversion of unpublished history. Original receipt commit IDs and evidence bytes remain immutable; verified aliases support ancestor checks only.')
with (folder / 'lfs-transport.json').open('x', encoding='utf-8') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
assert storage.verify_rewrite(root) == aliases
output = work / 'lfs-conversion-verification-v1.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(dict(status='verified', original_tip=record['original_tip'], rewritten_tip=tip,
        remote_base=record['remote_base'], commits=len(aliases), archives=len(record['archives']),
        original_metadata_sha256=record['objects_sha256'], mapping_sha256=manifest['mapping_sha256'],
        free_bytes=shutil.disk_usage(str(root)).free), stream, indent=2)
    stream.write('\n')
print(output.read_text(encoding='utf-8'), flush=True)
