import { defineConfig } from '../../../scripts/oracles/official/node_modules/vitest/dist/config.js'
import base from '../../../scripts/oracles/vitest.acp.config.mts'

export default defineConfig({
  ...base,
  cacheDir: '.goose/out/acp-a4-work/vite-cache',
  test: { ...base.test, include: ['.goose/out/acp-a4-work/permissions.probe.spec.ts'] },
})
