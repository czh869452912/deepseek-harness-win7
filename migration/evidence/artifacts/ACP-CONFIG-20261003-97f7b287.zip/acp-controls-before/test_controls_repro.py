import importlib.util
import os
from pathlib import Path

import pytest

from dsh.acp.server import AcpPlugin
from dsh.cordis.context import Context
from test_acp_session_controls import bridge_fixture, dispose_context


def selected_plugin():
    if os.environ.get('ACP_CONTROLS_BEFORE') != '1':
        return AcpPlugin
    spec = importlib.util.spec_from_file_location('before_acp_controls', Path(__file__).with_name('before_server.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.AcpPlugin


@pytest.mark.asyncio
async def test_initialize_uses_stable_integer_version():
    ctx = Context()
    bridge = selected_plugin()()
    try:
        result = await bridge.initialize(ctx, {'protocolVersion': 0})
        assert result['protocolVersion'] == 1 and type(result['protocolVersion']) is int
    finally:
        await dispose_context(ctx)


@pytest.mark.asyncio
async def test_no_missing_provider_false_success(tmp_path):
    ctx = Context()
    bridge = selected_plugin()()
    try:
        with pytest.raises(RuntimeError, match='requires agents'):
            await bridge.new_session(ctx, {'cwd': str(tmp_path)})
    finally:
        await dispose_context(ctx)


async def owned_fixture():
    ctx, ignored, persistence, factory = bridge_fixture()
    bridge = selected_plugin()()
    create = factory.create
    async def compatible_create(**kwargs):
        kwargs.setdefault('signal', None)
        return await create(**kwargs)
    factory.create = compatible_create
    return ctx, bridge, persistence, factory


async def cleanup(ctx, bridge):
    if hasattr(bridge, 'close'):
        await bridge.close(ctx)
    else:
        for record in bridge.sessions.values():
            await record.dispose_fn()
    await dispose_context(ctx)


@pytest.mark.asyncio
async def test_new_empty_session_is_materialized(tmp_path):
    ctx, bridge, persistence, factory = await owned_fixture()
    try:
        created = await bridge.new_session(ctx, {'cwd': str(tmp_path)})
        assert created['sessionId'] in persistence.headers
    finally:
        await cleanup(ctx, bridge)


@pytest.mark.asyncio
async def test_close_releases_owned_session_for_list_resume(tmp_path):
    ctx, bridge, persistence, factory = await owned_fixture()
    try:
        created = await bridge.new_session(ctx, {'cwd': str(tmp_path)})
        assert await bridge.close_session(ctx, created) == {}
        assert await bridge.list_sessions(ctx, {}) == {'sessions': [dict(created, cwd=str(tmp_path))]}
        assert await bridge.resume_session(ctx, dict(created, cwd=str(tmp_path))) == {}
    finally:
        await cleanup(ctx, bridge)
