import asyncio,json,sys,os
from pathlib import Path
sys.path.insert(0,'C:/Users/czh86/.codex/worktrees/acp-mcp-closure/deepseek-harness-win7')
from dsh.mcp.transport import StdioMcpTransport
from dsh.mcp.stdio_client import McpError

async def main():
    os.environ['CONTROLLED_API_KEY']='must-not-inherit'
    os.environ['DSH_STALE']='must-not-inherit'
    client=StdioMcpTransport(sys.executable,['.goose/out/acp-a4-work/mcp_stdio_fixture.py'],env={'EXPLICIT_TOKEN':'fixture-only'})
    notifications=[]
    client.on_notification=notifications.append
    try:
        await client.connect()
        tools=await client.list_tools()
        calls=await asyncio.gather(*(client.call_tool('echo',{'text':str(index)}) for index in range(8)))
        try:
            await client.call_tool('echo',{'error':True})
        except McpError as failure:
            error={'code':failure.code,'message':str(failure),'data':failure.data}
        result={'protocol':client.protocol_version,'server':client.server_info,'tools':tools,'calls':calls,'error':error,'notifications':notifications}
    finally:
        await client.close()
    Path('.goose/out/acp-a4-work/mcp-stdio-native.python.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
asyncio.run(main())
