import {Connection, Handled} from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/jsonrpc.js';
import {ndJsonStream} from '../../../scripts/oracles/official/node_modules/@agentclientprotocol/sdk/dist/stream.js';
import {readFileSync, writeFileSync} from 'node:fs';

const observations = [];
for (const {mode, bytes} of JSON.parse(readFileSync(process.argv[2], 'utf8'))) {
  const output = [];
  let input;
  const readable = new ReadableStream({start(controller) {input = controller;}});
  const writable = new WritableStream({write(frame) {output.push(JSON.parse(new TextDecoder().decode(frame)));}});
  const connection = new Connection(ndJsonStream(writable, readable), [{async handleMessage(message) {
    if (message.kind !== 'request' || message.method !== 'echo') return Handled.no(message);
    await message.responder.respond(message.params ?? null);
    return Handled.yes();
  }}]);
  for (const byte of Buffer.from(bytes, 'base64')) input.enqueue(new Uint8Array([byte]));
  for (let iteration = 0; iteration < 100; iteration++) await new Promise(resolve => setImmediate(resolve));
  input.close();
  await connection.closed;
  for (let iteration = 0; iteration < 20; iteration++) await new Promise(resolve => setImmediate(resolve));
  observations.push({mode, output});
}
writeFileSync(process.argv[3], JSON.stringify(observations, null, 2));
