import { defineConfig } from '../../../scripts/oracles/official/node_modules/vitest/dist/config.js'
import base from '../../../scripts/oracles/vitest.acp.config.mts'

export default defineConfig({ ...base, test: { ...base.test, include: ['.goose/out/acp-next/model_output.probe.spec.ts'], testTimeout: 30000 } })
