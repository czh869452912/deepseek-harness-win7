import { InitializeResultSchema, ListToolsResultSchema } from '../../../scripts/oracles/official/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js'
import { writeFileSync } from 'node:fs'

const base = {protocolVersion:'2025-11-25',capabilities:{tools:{}},serverInfo:{name:'controlled',version:'1.0'}}
const cases = [
  ['logging-array', InitializeResultSchema, {...base,capabilities:{tools:{},logging:[]}}],
  ['experimental-scalar', InitializeResultSchema, {...base,capabilities:{experimental:{extension:false}}}],
  ['annotation-scalar', ListToolsResultSchema, {tools:[{name:'echo',inputSchema:{type:'object'},annotations:false}]}],
  ['property-array', ListToolsResultSchema, {tools:[{name:'echo',inputSchema:{type:'object',properties:{value:[]}}}]}],
  ['unknown-tool-field', ListToolsResultSchema, {tools:[{name:'echo',inputSchema:{type:'object'},unknown:'retained?'}]}],
]
const observations=cases.map(([mode,schema,input])=>{
  const result=schema.safeParse(input)
  return {mode,input,passed:result.success,...result.success?{output:result.data}:{issues:result.error.issues}}
})
writeFileSync('.goose/out/acp-a4-work/mcp-schema-gaps.source.json',JSON.stringify(observations,null,2)+'\n')
