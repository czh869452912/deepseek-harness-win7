import asyncio
from types import SimpleNamespace

import pytest

from dsh.acp.server import AcpPlugin, SessionRecord
from dsh.cordis.context import Context
from dsh.core.session import Session


def record(session_id, turn):
    result = SessionRecord(SimpleNamespace(session=Session(session_id)))
    result.inflight_prompt = {'msg_id': session_id + '-message', 'turn': turn,
                              'done': False, 'stop_reason': 'end_turn'}
    return result


def test_turn_end_is_owned_by_exact_session_and_claimed_turn():
    bridge = AcpPlugin()
    first, second = record('alpha', 1), record('beta', 1)
    bridge.sessions = {'alpha': first, 'beta': second}
    bridge._on_session_event(first.agent.session, {'type': 'turn/end',
        'data': {'turn': 1, 'reason': {'kind': 'interrupted'}}})
    assert first.inflight_prompt['stop_reason'] == 'cancelled'
    assert second.inflight_prompt['stop_reason'] == 'end_turn'


@pytest.mark.parametrize('impostor', [False, True])
def test_wrong_turn_or_same_id_session_impostor_cannot_change_result(impostor):
    bridge = AcpPlugin()
    owned = record('alpha', 2)
    bridge.sessions = {'alpha': owned}
    observed = Session('alpha') if impostor else owned.agent.session
    bridge._on_session_event(observed, {'type': 'turn/end',
        'data': {'turn': 2 if impostor else 1, 'reason': {'kind': 'max-tokens'}}})
    assert owned.inflight_prompt['stop_reason'] == 'end_turn'


def test_claim_correlates_only_owned_agent_and_prompt_message():
    bridge = AcpPlugin()
    owned = record('alpha', None)
    bridge.sessions = {'alpha': owned}
    bridge._on_inbox_claimed({'agent': owned.agent,
        'message': {'id': 'alpha-message'}, 'turn': 4})
    assert owned.inflight_prompt['turn'] == 4
