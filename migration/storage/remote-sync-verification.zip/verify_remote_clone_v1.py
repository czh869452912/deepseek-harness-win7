import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time


root = Path(__file__).resolve().parents[3]
clone = root / '.goose/out/lfs-remote-clone-20261007'
manifest = json.loads((clone / 'migration/storage/lfs-transport.json').read_text(encoding='utf-8'))
started = time.perf_counter()
assert not (clone / '.git/objects/info/alternates').exists()
original_absent = subprocess.run(['git', '-C', str(clone), 'cat-file', '-e', manifest['original_tip'] + '^{commit}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE).returncode != 0
assert original_absent
for archive in manifest['archives']:
    destination = clone / archive['path']
    pointer = 'version https://git-lfs.github.com/spec/v1\noid sha256:{}\nsize {}\n'.format(archive['sha256'], archive['size']).encode('ascii')
    assert destination.read_bytes() == pointer
    source = root / archive['path']
    destination.unlink()
    os.link(str(source), str(destination))
spec = importlib.util.spec_from_file_location('remote_clone_storage', clone / 'scripts/migration_storage.py')
storage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(storage)
aliases = storage.verify_rewrite(clone)
assert len(aliases) == 126
assert subprocess.run(['git', '-C', str(clone), 'merge-base', '--is-ancestor', manifest['remote_base'], 'HEAD']).returncode == 0
check = subprocess.run([str(root / '.venv/Scripts/python.exe'), str(clone / 'scripts/migration.py'), 'check', '--root', str(clone)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf-8')
log = root / '.goose/out/acp-a4-work/remote-clone-migration-check-v1.log'
log.write_text(check.stdout, encoding='utf-8')
assert check.returncode == 0, 'new remote clone migration check failed; see retained log'
record = dict(result='passed', clone_origin=subprocess.check_output(['git', '-C', str(clone), 'remote', 'get-url', 'origin'], encoding='ascii').strip(), head=subprocess.check_output(['git', '-C', str(clone), 'rev-parse', 'HEAD'], encoding='ascii').strip(), upstream=subprocess.check_output(['git', '-C', str(clone / 'reference'), 'rev-parse', 'HEAD'], encoding='ascii').strip(), aliases=len(aliases), archives=len(manifest['archives']), bytes=sum(archive['size'] for archive in manifest['archives']), no_alternates=True, original_commit_absent=original_absent, migration_check=True, scope='Git code/metadata/history and reference fetched from remote; actual archive bytes supplied through local verified immutable hardlinks to avoid disk duplication. Remote availability and full streamed downloads verified separately.', seconds=time.perf_counter() - started)
(root / '.goose/out/acp-a4-work/remote-clone-verification-v1.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record), flush=True)
