import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
folder = root / 'migration/storage'
manifest_path = folder / 'lfs-transport.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
mapping = root / manifest['mapping_path']
mapping.write_bytes(mapping.read_text(encoding='utf-8').encode('utf-8'))
manifest['mapping_sha256'] = hashlib.sha256(mapping.read_bytes()).hexdigest()
manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode('utf-8'))
sources = {name: work / name for name in (
    'migration-storage-focused-v1.xml', 'migration-storage-focused-v1.log',
    'migration-storage-focused-v2.xml', 'migration-storage-focused-v2.log',
    'migration-storage-focused-v3.xml', 'migration-storage-focused-v3.log',
    'prepare_lfs_history_v1.py', 'finish_lfs_history_v1.py', 'audit_remote_sync_v1.py',
    'remote-sync-audit-v1.json', 'lfs-preserved-inputs-v1.json', 'lfs-preserve-inputs-v1.log',
    'lfs-original-backup-fsck-v1.log', 'lfs-history-import-v1.log',
    'lfs-conversion-verification-v1.log', 'lfs-conversion-verification-v1-retry.log',
    'lfs-conversion-verification-v1-write-retry.log', 'lfs-conversion-verification-v2.log',
    'diagnose_lfs_attributes_v1.py', 'lfs-attributes-diagnostic-v1.log', 'inspect_lfs_file_owner_v1.py')}
sources['producer.py'] = Path(__file__)
for name in ('scripts/migration.py', 'scripts/migration_storage.py', 'tests/test_migration_storage.py',
        '.gitattributes', '.github/workflows/verify.yml'):
    sources['after/' + name] = root / name
members = {name: dict(size=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    for name, path in sources.items()}
archive_path = folder / 'storage-qualification.zip'
with zipfile.ZipFile(str(archive_path), 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sources.items():
        archive.write(str(path), name)
    archive.writestr('manifest.json', json.dumps(dict(members=members,
        original_tip=manifest['original_tip'], rewritten_tip=manifest['rewritten_tip'],
        qualification='44 focused regressions including actual LFS import and clone without old commit objects. Actual 126-commit/86-archive conversion verified. Only empty attribute lines normalized; all nonempty rules/comments exact. Root archive sharing locks retained, verified copies restore pointer content without deleting cached originals. No full product acceptance or Source exception.'), indent=2) + '\n')
with zipfile.ZipFile(str(archive_path)) as archive:
    assert archive.testzip() is None
    for name, expected in members.items():
        body = archive.read(name)
        assert len(body) == expected['size'] and hashlib.sha256(body).hexdigest() == expected['sha256']
record = dict(path=archive_path.relative_to(root).as_posix(), sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    members=len(members) + 1, mapping_sha256=manifest['mapping_sha256'], objects_sha256=manifest['objects_sha256'])
with (work / 'lfs-storage-qualification-collection-v1.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
