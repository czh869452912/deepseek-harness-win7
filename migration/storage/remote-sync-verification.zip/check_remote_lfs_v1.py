import base64
import hashlib
import json
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request


root = Path(__file__).resolve().parents[3]
manifest = json.loads((root / 'migration/storage/lfs-transport.json').read_text(encoding='utf-8'))
credentials = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\npath=czh869452912/deepseek-harness-win7.git\n\n', encoding='utf-8', stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
fields = dict(line.split('=', 1) for line in credentials.stdout.splitlines() if '=' in line)
authorization = base64.b64encode((fields['username'] + ':' + fields['password']).encode('utf-8')).decode('ascii')
endpoint = 'https://github.com/czh869452912/deepseek-harness-win7.git/info/lfs/objects/batch'
output = root / '.goose/out/acp-a4-work/remote-lfs-availability-v1.json'
record = dict(operation='download', files=[], failures=[])
for start in range(0, len(manifest['archives']), 5):
    archives = manifest['archives'][start:start + 5]
    body = json.dumps(dict(operation='download', transfers=['basic'], objects=[dict(oid=entry['sha256'], size=entry['size']) for entry in archives])).encode('utf-8')
    request = urllib.request.Request(endpoint, data=body, headers={'Authorization': 'Basic ' + authorization, 'Accept': 'application/vnd.git-lfs+json', 'Content-Type': 'application/vnd.git-lfs+json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            result = json.load(response)
        received = {entry['oid']: entry for entry in result['objects']}
        for archive in archives:
            actual = received[archive['sha256']]
            assert actual['size'] == archive['size']
            available = 'download' in actual.get('actions', {}) and 'error' not in actual
            record['files'].append(dict(path=archive['path'], oid=archive['sha256'], size=archive['size'], available=available, error_code=actual.get('error', {}).get('code')))
        print(json.dumps(dict(batch=start // 5, available=sum(entry['available'] for entry in record['files']), examined=len(record['files']))), flush=True)
    except Exception as error:
        code = error.code if isinstance(error, urllib.error.HTTPError) else None
        record['failures'].append(dict(batch=start // 5, type=type(error).__name__, http_status=code))
        print(json.dumps(record['failures'][-1]), flush=True)
        if len(record['failures']) >= 3:
            break
    finally:
        output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
record['complete'] = len(record['files']) == len(manifest['archives']) and all(entry['available'] for entry in record['files']) and not record['failures']
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(complete=record['complete'], available=sum(entry['available'] for entry in record['files']))), flush=True)
