import { defineConfig } from '../../../scripts/oracles/official/node_modules/vitest/dist/config.js'
import base from '../../../scripts/oracles/vitest.acp.config.mts'

export default defineConfig({ ...base, cacheDir: '.goose/out/acp-a4-work/mcp-vite-cache',
  test: {...base.test, include: ['C:/Users/czh86/.codex/worktrees/acp-mcp-closure/deepseek-harness-win7/scripts/oracles/mcp_stdio.probe.spec.ts']} })
