from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
FOLDER = Path(__file__).resolve().parent
mapping = {name + '.py': 'dsh/acp/' + name + '.py' for name in ('model_control', 'content', 'updates', 'session_runtime')}
mapping.update({'test_acp_model_output.py': 'tests/test_acp_model_output.py',
                'test_acp_output_lifecycle.py': 'tests/test_acp_output_lifecycle.py',
                'model_output.probe.spec.ts': 'scripts/oracles/acp_model_output.probe.spec.ts'})
for index, (name, target) in enumerate(mapping.items()):
    path = ROOT / target
    body = (FOLDER / name).read_text(encoding='utf-8')
    if name.endswith('.ts'):
        body = body.replace('../../../scripts/oracles/official/', './official/').replace('../../../reference/', '../../reference/')
    patch = '*** Begin Patch\n'
    if path.is_file():
        patch += '*** Update File: ' + str(path) + '\n@@\n' + ''.join('-' + line + '\n' for line in path.read_text(encoding='utf-8').splitlines())
    else:
        patch += '*** Add File: ' + str(path) + '\n'
    patch += ''.join('+' + line + '\n' for line in body.splitlines()) + '*** End Patch\n'
    (FOLDER / ('promote-' + str(index) + '.patch')).write_text(patch, encoding='utf-8')
