import { writeFileSync } from 'node:fs'
import { expect, it } from 'vitest'
import ApprovalService from '@deepseek-ai/dsh-user-approval'
import { makeBridgeHarness } from '../../../reference/packages/acp/acp/tests/harness.ts'

it('records exact machine permission decisions against original source', async () => {
  const rows = []
  for (const [mode, response] of [
    ['allow', {outcome: {outcome: 'selected', optionId: 'allow-once'}}],
    ['reject', {outcome: {outcome: 'selected', optionId: 'reject-once'}}],
    ['unknown-option', {outcome: {outcome: 'selected', optionId: 'allow-always'}}],
    ['cancelled', {outcome: {outcome: 'cancelled'}}],
    ['unknown-kind-allow', {outcome: {outcome: 'unknown', optionId: 'allow-once'}}],
    ['missing-kind-allow', {outcome: {optionId: 'allow-once'}}],
    ['missing-outcome', {}],
    ['null-response', null],
  ] as const) {
    const harness = await makeBridgeHarness()
    try {
      await harness.ctx.plugin(ApprovalService)
      const {sessionId} = await harness.client.newSession({cwd: process.cwd(), mcpServers: []})
      const agent = harness.ctx.agents.get(sessionId as any)!
      agent.session.append('turn/start', {turn: 1})
      agent.session.append('step/start', {turn: 1, step: 1})
      agent.session.append('tool/call', {turn: 1, step: 1, callId: 'call-9' as any, name: 'bash', arguments: '{}'})
      harness.onPermission = () => response as any
      const outcome = await harness.ctx.approval.request({agent, toolName: 'bash', callId: 'call-9' as any})
      rows.push({mode, outcome, requests: harness.permissionRequests, updates: harness.sessionUpdates})
    } finally {await harness.dispose()}
  }
  expect(rows).toHaveLength(8)
  writeFileSync('.goose/out/acp-a4-work/permissions-source.json', JSON.stringify(rows, null, 2))
})
