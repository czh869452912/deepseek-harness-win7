import { writeFileSync } from 'node:fs'
import { expect, it, vi } from 'vitest'
import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { ToolListChangedNotificationSchema } from '@modelcontextprotocol/sdk/types.js'
import { createTransport } from '../../../reference/packages/mcp/mcp-client/src/transport.ts'

it('observes original stdio provider and SDK with controlled child environment', async () => {
  vi.stubEnv('CONTROLLED_API_KEY', 'must-not-inherit')
  vi.stubEnv('DSH_STALE', 'must-not-inherit')
  const client = new Client({ name: 'dsh-mcp-client', version: '0.0.1' }, { capabilities: {} })
  const notifications = []
  client.setNotificationHandler(ToolListChangedNotificationSchema, packet => { notifications.push(packet) })
  const transport = createTransport({ transport: 'stdio', command: process.env.MCP_FIXTURE_PYTHON!,
    args: ['.goose/out/acp-a4-work/mcp_stdio_fixture.py'], cwd: process.cwd(), env: {EXPLICIT_TOKEN:'fixture-only'} } as any)
  let result
  try {
    await client.connect(transport)
    const tools = await client.listTools()
    const calls = await Promise.all(Array.from({ length: 8 }, (_, index) => client.callTool({name:'echo', arguments:{text:String(index)}})))
    let error
    try { await client.callTool({name:'echo', arguments:{error:true}}) } catch (failure: any) {
      error={code:failure.code,message:failure.message,data:failure.data}
    }
    result={protocol:'2025-11-25',server:client.getServerVersion(),tools,calls,error,notifications}
    expect(calls).toHaveLength(8)
  } finally {await client.close(); vi.unstubAllEnvs()}
  writeFileSync('.goose/out/acp-a4-work/mcp-stdio-original.source.json',JSON.stringify(result,null,2))
})
