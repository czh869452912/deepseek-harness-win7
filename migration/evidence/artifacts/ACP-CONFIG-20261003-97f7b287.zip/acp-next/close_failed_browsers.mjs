import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {basename, dirname, join, resolve} from 'node:path';
import {tmpdir} from 'node:os';

const observations = [];
const paths = JSON.parse(await readFile('.goose/out/acp-next/failed-owned-browser-paths.json', 'utf8'));
for (const directory of paths) {
  const target = resolve(directory);
  assert.equal(resolve(dirname(target)), resolve(tmpdir()));
  assert.match(basename(target), /^dsh-(?:web-package-cdp|cdp)-[A-Za-z0-9]+$/);
  try {
    const [port, endpoint] = (await readFile(join(target, 'DevToolsActivePort'), 'utf8')).trim().split(/\r?\n/);
    assert.match(port, /^\d+$/);
    assert.match(endpoint, /^\/devtools\/browser\/[A-Za-z0-9-]+$/);
    await new Promise((done, fail) => {
      const socket = new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
      const timer = setTimeout(() => {socket.close(); fail(new Error('owned browser close timed out'));}, 15000);
      socket.addEventListener('open', () => socket.send(JSON.stringify({id: 1, method: 'Browser.close', params: {}})));
      socket.addEventListener('close', () => {clearTimeout(timer); done();});
      socket.addEventListener('error', () => {clearTimeout(timer); fail(new Error('owned browser endpoint unavailable'));});
    });
    observations.push({directory: target, protocolClosed: true});
  } catch (error) {observations.push({directory: target, protocolClosed: false, detail: String(error)});}
}
await writeFile('.goose/out/acp-next/failed-owned-browser-close.json', JSON.stringify(observations, null, 2), 'utf8');
console.log(JSON.stringify(observations));
