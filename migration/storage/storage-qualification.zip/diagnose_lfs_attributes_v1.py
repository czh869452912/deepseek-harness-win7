import csv
import difflib
import json
from pathlib import Path
import sys
import zipfile


root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from scripts import migration_storage as storage


record = json.loads((root / 'migration/storage/lfs-transport.json').read_text(encoding='utf-8'))
aliases = dict(csv.reader((root / record['mapping_path']).read_text(encoding='utf-8').splitlines()))
reader = storage.GitObjects(root)
try:
    with zipfile.ZipFile(str(root / record['objects_path'])) as package:
        for old, new in aliases.items():
            before_tree = storage.commit_parts(package.read('commit/' + old))[0]
            after_tree = storage.commit_parts(reader.read(new, 'commit'))[0]
            before_entries = storage.tree_entries(package.read('tree/' + before_tree))
            after_entries = storage.tree_entries(reader.read(after_tree, 'tree'))
            old_attribute = before_entries.get(b'.gitattributes')
            new_attribute = after_entries.get(b'.gitattributes')
            before = package.read('blob/' + old_attribute[1]).splitlines() if old_attribute else []
            after = reader.read(new_attribute[1], 'blob').splitlines()
            if storage.TRACKING in after:
                after.remove(storage.TRACKING)
            while before and not before[-1]:
                before.pop()
            while after and not after[-1]:
                after.pop()
            if before != after:
                print(json.dumps(dict(old=old, new=new)))
                print('\n'.join(difflib.unified_diff([line.decode('utf-8') for line in before],
                    [line.decode('utf-8') for line in after], fromfile='original', tofile='converted', lineterm='')))
                break
finally:
    reader.close()
